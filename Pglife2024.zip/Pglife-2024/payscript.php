<?php
session_start();
require "includes/database_connect.php";

if (!isset($_SESSION["user_id"])) {
    header("location: index.php");
    die();
}

?>



<?php
$name = $_POST['name'];
$email = $_POST['email'];
$total = $_POST['total'];
$plan = $_POST['plan'];
$mobile = $_POST['mobile'];
$address = $_POST['address'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirm to Pay</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="pay.css">
</head>

<body>
    <div class="container">
        <div class="pament_main">
            <h2 class="h3 text-center">Click the Pay button for payment! </h2>
            <br>
            <div>
                <button class="btn btn-success" id="rzp-button1"> Pay with Razorpay</button>
            </div>
        </div>
    </div>
    <!-- <div>

        <pre> </pre>

    </div> -->
    <script src="https://checkout.razorpay.com/v1/checkout.js"></script>
    <script>
        var options = {
            "key": "rzp_test_VcuDjP7uwPrvkJ", // Enter the Key ID generated from the Dashboard
            "amount": "<?php echo $total * 100; ?>", // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise
            "currency": "INR",
            "name": "PG Life",
            "description": "Transaction for <?php echo $plan; ?>",
            "image": "logo.png",
            // "id": "Bookid_".(rand(1,100).rand(a,z).rand(A,Z)), //This is a sample Order ID. Pass the `id` obtained in the response of Step 1
            "callback_url": "thank.php",
            "prefill": {
                "name": "<?php echo $name; ?>",
                "email": "<?php echo $email; ?>",
                "contact": "<?php echo $mobile; ?>"
            },
            "notes": {
                "address": "<?php echo $address; ?>"
            },
            "theme": {
                "color": "#3399cc"
            }
        };
        var rzp1 = new Razorpay(options)
        document.getElementById('rzp-button1').onclick = function (e) {
            rzp1.open();
            e.preventDefault();
        }
    </script>

    <script>
        window.onload = function () {
            document.getElementById('rzp-button1').click();
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>