<?php
session_start();
require "includes/database_connect.php";

if (!isset($_SESSION["user_id"])) {
    header("location: index.php");
    die();
}

?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Details</title>
    <?php
    include "includes/head_links.php";
    ?>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="order.css">

</head>

<body>
<?php
    include "includes/header.php";
    ?>
    <div class="container order_main">
        <div>
            <div class="card-body1">
                <form action="db.php" method="post">
                    <div>
                        <h2 style="text-align:center;"><u>ORDER DETAILS</u></h2>
                    </div>

                    <div class="mb-3">
                        <!-- <label class="form-label">Name</label> -->
                        <b>Name :</b>
                        <input type="text" class="form-control" name="name" required>
                    </div>


                    <div class="mb-3">
                        <!-- <label class="form-label">Mobile</label> -->
                        <b>Mobile :</b>
                        <input type="text" class="form-control" name="mobile" required>
                    </div>

                    <div class="mb-3">
                        <!-- <label class="form-label">Aadhar Number</label> -->
                        <b>Email Id:</b>
                        <input type="email" class="form-control" name="email" required>
                    </div>

                    <div class="mb-3">
                        <!-- <label class="form-label">Address</label> -->
                        <b>Address :</b>
                        <input type="text" class="form-control" name="address" required>
                    </div>
                    <div class="mb-3">
                        <!-- <label class="form-label">Address</label> -->
                        <b>Check In :</b>
                        <input type="date" class="form-control" name="cin" required>
                    </div>
                    <div class="mb-3">
                        <!-- <label class="form-label">Address</label> -->
                        <b>Check Out :</b>
                        <input type="date" class="form-control" name="cout" required>
                    </div>

                    <div class="mb-3">
                        <!-- <label class="form-label">Choose Plans</label> -->
                        <b>Choose Hotel :</b>
                        <select class="form-select" name="plan" required id="plan">
                            <option selected>-----Select One Hotel-----</option>
                            <option>Saxena's Paying Guest</option>
                            <option>Navrang PG Home</option>
                            <option>Navkar Paying Guest</option>
                            <option>PG for Girls Borivali West</option>
                            <option>Ganpati Paying Guest</option>
                            <option>Hotel Monalisa</option>
                        </select>
                    </div>

                    <!-- <div class="mb-3"> -->
                    <!-- <label class="form-label">Room Quantity</label> -->
                    <!-- <b>Room Quantity :</b>
                    <div class="number">
                        <span class="minus">-</span>
                        <input type="number" value="1" id="qty" name="qty">
                        <span class="plus">+</span>
                        <img src="razorpay.png" alt="RazorPay" height="50px" width="180px" class="pay_photo">
                    </div>
                     </div> -->


                    <!-- <div class="mb-3">
                        <label class="form-label">Total Price(Include 18% GST)</label>
                        <b>Total Price(Include 18% GST) :</b>
                        <input id="total" type="number" class="form-control" name="total" readonly required>
                    </div> -->

                    <div class="text-center">
                        <button type="submit" class="btn btn-primary">CONTINUE</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>

</html>