<?php
session_start();
require "includes/database_connect.php";

if (!isset($_SESSION["user_id"])) {
    header("location: index.php");
    die();
}

?>



<!DOCTYPE html>
<html>

<head>
    <title>Order id</title>
</head>

<body>
    <!-- <div class="belement">

        <table>
            <tr>
                <th>Booked Pg Name</th>
                <th>Plan Name</th>
                <th>Amount</th>
            </tr>
            <tr>
                <td>Saxena's Paying Guest</td>
                <td>With Food</td>
                <td>7080</td>
            </tr>
        </table>
        <form action="cb.php" method="POST">
            <div class="random">
                <p>Order Id / Transaction Id : </p>
                <div class="randombody">

                    <p id="demo"></p>
                    <script>
                        let x = (Math.floor((Math.random() * 1000000) + 1000));
                        document.getElementById("demo").innerHTML = x;
                    </script>
                </div>
            </div>
        </form>
    </div> -->
    <div class="dpd">
        <div class="disclamer">
            <ul>
                <li>
                    <h3>Don't forgot download the invoice</h3>
                </li>
                <li>
                    <h3>Do not press back key</h3>
                </li>
                <li>
                    <h3>Do not refresh the page</h3>
                </li>
            </ul>
            <div class="conbut">
                <div class="conbut">
                    <a href="pdf.php" class="button">Download Invoice</a>
                </div>
            </div>
            <h4 style="padding:0px 12px 2px 12px;"><u style="color:red;">Please Note</u>: Bring this receive copy at the time of check-in at the PG. Because without receiving you can't enter inside.</h4>
        </div>

    </div>


</body>


<script>
    window.onload = function () {
        document.getElementById("download")
            .addEventListener("click", () => {
                const invoice = this.document.getElementById("invoice");
                console.log(invoice);
                console.log(window);
                var opt = {
                    margin: 1,
                    filename: 'Prescription.pdf',
                    image: { type: 'jpeg', quality: 1 },
                    html2canvas: { scale: 2 },
                    jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
                };
                html2pdf().from(invoice).set(opt).save();
            })
    }
</script>


<style>
    body{
        background-image: url("ord.png");
        background-repeat: no-repeat;
        background-size: cover;
    }

    .button {
        background-color: green;
        border: none;
        color: white;
        padding: 10px 40px;
        text-align: center;
        border-radius: 5px;
        text-decoration: none;
        display: inline-block;
        font-size: 15px;
        margin: 8px 2px;
        cursor: pointer;
    }

    .random {
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 18px;
        border: 1px solid blue;
    }

    .randombody {
        display: grid;
        align-items: center;
        justify-content: center;
    }

    .conbut {
        display: flex;
        align-items: center;
        justify-content: center;
        /* border: 1px solid blue; */


    }

    .disclamer {
        background-color: antiquewhite;
        margin: 180px 450px 0px 450px;
        border: 2px solid blue;
        border-radius: 10px;

    }


    .belement {
        display: grid;
        align-items: center;
        justify-content: center;
        border: 1px solid blue;
        margin: 100px 460px 10px 460px;

    }

    table {
        font-family: arial, sans-serif;
        border-collapse: collapse;
        width: 100%;
    }

    td,
    th {
        border: 1px solid blue;
        text-align: left;
        padding: 8px;
    }

    tr:nth-child(odd) {
        background-color: #dddddd;
    }
</style>

<script type="text/javascript" src="js/property_detail.js"></script>