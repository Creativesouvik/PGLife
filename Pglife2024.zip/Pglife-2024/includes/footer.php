<div class="footer">
    <div class="page-container footer-container">
        <div class="footer-cities">
            <div class="footer-city">
                <a href="property_list.php?city=Delhi">PG in Delhi</a>
            </div>
            <div class="footer-city">
                <a href="property_list.php?city=Mumbai">PG in Mumbai</a>
            </div>
            <div class="footer-city">
                <a href="property_list.php?city=Bengaluru">PG in Bangalore</a>
            </div>
            <div class="footer-city">
                <a href="property_list.php?city=Hyderabad">PG in Hyderabad</a>
            </div>
        </div>
        <div class="footer-copyright">© 2020 Copyright PG Life </div>
    </div>
</div>

<script type="text/javascript" src="js/jquery.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>
