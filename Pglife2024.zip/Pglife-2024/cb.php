<!-- <div class="my-profile page-container">
        <h1>My Orders</h1>
        <div class="row">
            <div class="col-md-3 profile-img-container">
            <i class='fas fa-luggage-cart' style='font-size:48px;color:green;padding-left: 35px;'></i>
            </div>
            <div class="col-md-9">
                <div class="row no-gutters justify-content-between align-items-end">
                    <div class="profile"> -->
                        <?php
                        $servername = "localhost";
                        $username = "root";
                        $password = "";
                        $dbname = "pglife";

                        // Create connection
                        $conn = new mysqli($servername, $username, $password, $dbname);

                        // Check Connection
                        if ($conn->connect_error) {
                            die("Connection faild: " . $conn->connect_error);
                        }

                        $sql = "SELECT email,cin,cout,plan FROM db";
                        $result = $conn->query($sql);

                        if ($result->num_rows > 0) {
                            //output data of each row
                            while ($row = $result->fetch_assoc()) {
                                $b = $row["email"] . "<br>";
                                $c = $row["plan"] . "<br>";
                                $d = $row["cin"] . "<br>";
                                $e = $row["cout"] . "<br>";
                                echo "$d";
                                echo "$e";
                            }
                        } else {
                            echo "0 results";
                        }

                        $a = $user['email'];
                        // echo "$a"."<br>";
                        
                        if (isset($a) != $b) {
                            echo "You have't any order";
                        } else {
                            echo "You have a order for : ";
                            echo "$c";
                            echo "Your check in date : ";
                            echo "$d";
                            echo "Your check out date : ";
                            echo "$e";
                        }
                        $conn->close();
                        ?>
                    <!-- </div>
                    <div>
                        <div class="active-order">•Active</div>
                    </div>
                </div>
            </div>
        </div>
    </div> -->