<?php
session_start();
require "includes/database_connect.php";

if (!isset($_SESSION["user_id"])) {
  header("location: index.php");
  die();
}

?>



<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>RazorPay</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="pay.css">
</head>

<body>

  <div>
  <a href="index.php"><img src="logo.png" alt="LOGO" width="100px" height="50px"></a>
  </div>


  <div class="container parent_main">
    <div>
      <div class="card-body">
        <form action="payscript.php" method="post">

          <div>
            <h2 style="text-align:center;"><u>PAYMENT DETAILS</u></h2>
          </div>


          <div class="mb-3">
            <!-- <label class="form-label">Name</label> -->
            <b>Name :</b>
            <input type="text" class="form-control" name="name" required>
          </div>


          <div class="mb-3">
            <!-- <label class="form-label">Mobile</label> -->
            <b>Mobile :</b>
            <input type="text" class="form-control" name="mobile" required>
          </div>

          <div class="mb-3">
            <!-- <label class="form-label">Aadhar Number</label> -->
            <b>Email Id:</b>
            <input type="email" class="form-control" name="email" required>
          </div>

          <div class="mb-3">
            <!-- <label class="form-label">Address</label> -->
            <b>Address :</b>
            <input type="text" class="form-control" name="address" required>
          </div>

          <div class="mb-3">
            <!-- <label class="form-label">Choose Plans</label> -->
            <b>Choose Plans :</b>
            <select class="form-select" name="plan" required id="plan">
              <option selected>Select One Plan</option>
              <option value=<?php

              $date1 = date_create("2023-06-25");
              $date2 = date_create("2023-07-25");
              $m = 30;

              $diff = date_diff($date1, $date2);

              $days = $diff->format("%a");
              $rent = 6000 / $m;
              $tootal = $days * $rent;
              echo $tootal;
              ?>>Without Food - 6000/-
              </option>
              <!-- <option value="0">With Food</option>
              <option value="0">With Food+1</option> -->
            </select>
          </div>
          <!-- <div class="mb-3">
            <b style="color: white;text-align: center;">Total validity of your plan is
              <?php

              $date1 = date_create("2023-06-25");
              $date2 = date_create("2023-07-25");
              $m = 30;

              $diff = date_diff($date1, $date2);

              $time = $diff->format("%a");
              $month = $time / $m;
              $days = $time % $m;
              echo (int) $month;
              echo " monts ";
              echo $days;
              echo " days.";
              ?>
            </b>
          </div> -->

          <div class="mb-3">
            <!-- <label class="form-label">Room Quantity</label> -->
            <b>Room Quantity :</b>
            <div class="number">
              <span class="minus">-</span>
              <input type="text" value="1" id="qty" name="qty">
              <span class="plus">+</span>
              <img src="razorpay.png" alt="RazorPay" height="50px" width="180px" class="pay_photo">
            </div>
          </div>


          <div class="mb-3">
            <!-- <label class="form-label">Total Price(Include 18% GST)</label> -->
            <b>Total Price(Include 18% GST) :</b>
            <input id="total" type="number" class="form-control" name="total" readonly required>
          </div>

          <div class="text-center">
            <button type="submit" class="btn btn-primary">Pay with RazorPay</button>
          </div>
        </form>
      </div>
    </div>
  </div>


  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
  <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
  <script>
    $(document).ready(function () {

      var qty = parseInt($("#qty").val());

      $("#plan").change(function () {
        var amt = parseInt($("#plan").val());
        showAmt(amt, qty);
      });

      $('.minus').click(function () {
        var $input = $(this).parent().find('input');
        var count = parseInt($input.val()) - 1;
        count = count < 1 ? 1 : count;
        $input.val(count);
        $input.change();

        amt = parseInt($("#plan").val());
        qty = parseInt($("#qty").val());

        showAmt(amt, qty);
        return false;
      });

      $('.plus').click(function () {
        var $input = $(this).parent().find('input');
        $input.val(parseInt($input.val()) + 1);
        $input.change();

        amt = parseInt($("#plan").val());
        qty = parseInt($("#qty").val());

        showAmt(amt, qty);
        return false;
      });

      function showAmt(amt, qty) {
        amt = amt * qty;
        var gst = parseInt((amt * 0.18));
        $("#total").val(amt + gst);
      }
    });    
  </script>
</body>

</html>