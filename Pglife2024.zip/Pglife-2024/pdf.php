<?php
session_start();
require "includes/database_connect.php";

if (!isset($_SESSION["user_id"])) {
    header("location: index.php");
    die();
}
$user_id = $_SESSION['user_id'];

$sql_1 = "SELECT * FROM users WHERE id = $user_id";
$result_1 = mysqli_query($conn, $sql_1);
if (!$result_1) {
    echo "Something went wrong!";
    return;
}
$user = mysqli_fetch_assoc($result_1);
if (!$user) {
    echo "Something went wrong!";
    return;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css"
        crossorigin="anonymous">
    <link rel="stylesheet" href="pdf.css" />
    <script src="pdf.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.9.2/html2pdf.bundle.js"></script>
    <?php
    include "includes/head_links.php";
    ?>
</head>

<body>
    <?php
    include "includes/header.php";
    ?>

    <div class="container d-flex justify-content-center mt-50 mb-50">
        <div class="row">
            <div class="col-md-12 text-right mb-3">
                <button class="btn btn-primary" id="download"> download pdf</button>
            </div>
            <div class="col-md-12">
                <div class="card" id="invoice">
                    <div class="card-header bg-transparent header-elements-inline">
                        <h6 class="card-title text-primary">Booking invoice</h6>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="mb-4 pull-left">

                                    <ul class="list list-unstyled mb-0 text-left">
                                        <li>PGLife</li>
                                        <li>0342 256 8896</li>
                                        <li>Tnikonia,Bardhaman.</li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="mb-4 ">
                                    <div class="text-sm-right">
                                        <h4 class="invoice-color mb-2 mt-md-2">Invoice #PGL1243</h4>
                                        <!-- <ul class="list list-unstyled mb-0">
                                            <li>Check In Date: <span class="font-weight-semibold"></span>
                                            </li>
                                            <li>Check Out Date: <span class="font-weight-semibold">June 23, 2023</span>
                                            </li>
                                        </ul> -->
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br>
                        <div class="d-md-flex flex-md-wrap">
                            <div class="mb-4 mb-md-2 text-left"> <span class="text-muted">Invoice To:</span>
                                <ul class="list list-unstyled mb-0">
                                    <?php
                                    $servername = "localhost";
                                    $username = "root";
                                    $password = "";
                                    $dbname = "pglife";

                                    // Create connection
                                    $conn = new mysqli($servername, $username, $password, $dbname);

                                    // Check Connection
                                    if ($conn->connect_error) {
                                        die("Connection faild: " . $conn->connect_error);
                                    }

                                    $sql = "SELECT * FROM db";
                                    $result = $conn->query($sql);

                                    if ($result->num_rows > 0) {
                                        //output data of each row
                                        while ($row = $result->fetch_assoc()) {
                                            $b = $row["email"] . "<br>";
                                            $c = $row["plan"] . "<br>";
                                            $d = $row["cin"] . "<br>";
                                            $e = $row["cout"] . "<br>";
                                            $f = $row["name"] . "<br>";
                                            $g = $row["address"] . "<br>";
                                            // echo "$c";
                                        }
                                    } else {
                                        echo "0 results";
                                    }

                                    $a = $user['email'];
                                    // echo "$a"."<br>";
                                    
                                    if (isset($b) != $a) {
                                        echo "You have't any order";
                                    } else {
                                        echo "$f";
                                        echo "$g" . "<br>";

                                        echo "You have a order for : ";
                                        echo "$c";
                                        echo "Your check in date : ";
                                        echo "$d";
                                        echo "Your check out date : ";
                                        echo "$e";
                                    }
                                    $conn->close();
                                    ?>
                                </ul>
                            </div>


                            <div class="mb-2 ml-auto">
                                <div class="d-flex flex-wrap wmin-md-350">
                                    <div class="pt-2 mb-3 wmin-md-350 ml-auto">
                                        <h6 class="mb-3 text-left">Total Amount :</h6>
                                        <div class="table-responsive">
                                            <table class="table">
                                                <tbody>
                                                    <tr>
                                                        <th class="text-left">Subtotal:</th>
                                                        <td class="text-right">₹7080</td>
                                                    </tr>
                                                    <tr>
                                                        <th class="text-left">Total:</th>
                                                        <td class="text-right text-primary">
                                                            <h5 class="font-weight-semibold">₹7080</h5>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- <div class="table-responsive">
                        <table class="table table-lg">
                            <thead>
                                <tr>
                                    <th>Description</th>
                                    <th>Rate</th>
                                    <th>Hours</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        <h6 class="mb-0">Arts and design template</h6> <span class="text-muted">in
                                            reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
                                            pariatur.Duis aute irure dolor in reprehenderit</span>
                                    </td>
                                    <td>$120</td>
                                    <td>180</td>
                                    <td><span class="font-weight-semibold">$300</span></td>
                                </tr>
                                <tr>
                                    <td>
                                        <h6 class="mb-0">Template for desnging the arts</h6> <span class="text-muted">Lorem
                                            ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor</span>
                                    </td>
                                    <td>$140</td>
                                    <td>100</td>
                                    <td><span class="font-weight-semibold">$240</span></td>
                                </tr>
                                <tr>
                                    <td>
                                        <h6 class="mb-0">Technical support international</h6> <span class="text-muted">Lorem
                                            ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor</span>
                                    </td>
                                    <td>$250</td>
                                    <td>$250</td>
                                    <td><span class="font-weight-semibold">$500</span></td>
                                </tr>
                            </tbody>
                        </table>
                    </div> -->
                    <div class="card-body">
                        <div class="d-md-flex flex-md-wrap">

                        </div>
                        <div class="card-footer"> <span class="text-muted">Lorem ipsum dolor sit amet, consectetur
                                adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut
                                enim
                                ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                                consequat.Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore
                                eu
                                fugiat nulla pariatur.Duis aute irure dolor in reprehenderit</span>
                        </div>

                    </div>
                </div>
                <div>
                    <br><br>
                </div>
            </div>
            <pre>                                               <a href="logout.php"> <button type="button" class="btn btn-success">Go To Homepage</button></a></pre>
        </div>
</body>

</html>